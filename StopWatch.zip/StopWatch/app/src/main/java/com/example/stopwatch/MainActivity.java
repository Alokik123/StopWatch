package com.example.stopwatch;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Chronometer chronometer;
    private TextView displayTextView;
    private Button startButton, stopButton, resetButton;
    private boolean running;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chronometer = findViewById(R.id.chronometer);
        displayTextView = findViewById(R.id.displayTextView);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        resetButton = findViewById(R.id.resetButton);

        startButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!running) {
                    chronometer.setBase(SystemClock.elapsedRealtime());
                    chronometer.start();
                    running = true;
                }
            }
        });

        stopButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (running) {
                    chronometer.stop();
                    running = false;
                }
            }
        });

        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                chronometer.setBase(SystemClock.elapsedRealtime());
                running = false;
                updateDisplay(0);
            }
        });

        // Add a listener to the chronometer to update the display
        chronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
            @Override
            public void onChronometerTick(Chronometer chronometer) {
                // Calculate elapsed time in milliseconds
                long elapsedMillis = SystemClock.elapsedRealtime() - chronometer.getBase();
                updateDisplay(elapsedMillis);
            }
        });
    }

    private void updateDisplay(long elapsedMillis) {
        // Calculate minutes, seconds, and milliseconds
        int minutes = (int) (elapsedMillis / 60000);
        int seconds = (int) (elapsedMillis % 60000) / 1000;
        int milliseconds = (int) (elapsedMillis % 1000);

        // Display the time in the TextView
        displayTextView.setText(String.format("%02d:%02d:%03d", minutes, seconds, milliseconds));
    }
}
